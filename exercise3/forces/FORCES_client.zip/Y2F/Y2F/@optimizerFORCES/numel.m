function n = numel(varargin)
%NUMEL Overload of numel. Tell object to return one argument.
n = 1;

