% Generate a custom solver for multistage problems using FORCES Pro.
%
%    SUCCESS = GENERATECODE(STAGES) generates, downloads and compiles your
%    custom solver for the multistage problem STAGES. Default settings are
%    used, and the default parameter is 'stages(1).eq.c', i.e. the offset
%    term in the first equality constraint (as typically used in MPC). The
%    default output are all stage variables.
%
%    SUCCESS = GENERATECODE(STAGES,PARAMS) does the above but with user
%    defined parameters.
%
%    SUCCESS = GENERATECODE(STAGES,PARAMS,SETTINGS) does the above but with
%    user defined parameters and settings. A settings struct can be
%    obtained by calling the function GETOPTIONS first. See the embotech
%    online documentation for a detailed list of code settings.
%
%    SUCCESS = GENERATECODE(STAGES,PARAMS,SETTINGS,OUTVARS) does the above
%    but with user defined parameters, settings and outputs. Outputs are
%    defined by an array of structs obtained by NEWOUTPUT, or you can also
%    define all variables by using GETALLOUTPUTS.
%
%
% This file is part of the FORCES Pro client software for Matlab.
% (c) embotech AG, 2013-2018, Zurich, Switzerland. All rights reserved.
%
% See also MULTISTAGEPROBLEM NEWPARAM NEWOUTPUT GETOPTIONS

