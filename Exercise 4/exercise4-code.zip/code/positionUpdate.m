function posNew = positionUpdate(posOld, u, par)
TODO