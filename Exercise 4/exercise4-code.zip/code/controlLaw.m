function u = controlLaw(posRi, Mv, Lv)
TODO